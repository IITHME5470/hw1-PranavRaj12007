#include<stdio.h>

void f_input(int *dim) {
  FILE *fptr = fopen("input.in", "r");
  if (fptr == NULL) { 
    printf("No such file\n");
    }
  else {
    //printf("Opening input file\n");
    fscanf(fptr, "%d\n", dim);
    //printf("Dimension : %d\n", *dim);
    fclose(fptr);
    //printf("Dimension acquired. Closing file.\n");
  }
}

double mat_mul_row_op(double** A, double *v, int *dim, int row_num) {
    double entry = 0;
    int i;
    for(i=0; i<*dim; i++) {
    
      entry = entry + (A[row_num][i])*v[i];
    }
    
    return entry;
}

void eigen_evaluate(double** A, int *dim, int *vec_num) {
  char v_name[50];
  snprintf(v_name,sizeof(v_name),"vec_%06d_%06d.in",*dim, *vec_num);
  FILE *f_vec  = fopen(v_name, "a+");
  double *v = (double*)malloc((*dim) * sizeof(double));
  
  int i;
  for(i=0; i<*dim; i++) {
    if(i== *dim -1) {
      fscanf(f_vec, "%lf", &v[i]);
      }
    else {
      fscanf(f_vec, "%lf,", &v[i]);
      }
    //printf("%lf \t,",v[i]);
    }
    //printf("\n");
  
  double eigen_vec_entry, lambda;
  lambda = 0;
  int flag = 1;
  for (i=0; i<*dim; i++) {
    
    eigen_vec_entry = mat_mul_row_op(A, v, dim, i);
    
    //printf("Loop values \t %lf \t %lf \t %i\n", eigen_vec_entry/v[i] , v[i], i);
    if (v[i] == 0) {
        if (fabs(eigen_vec_entry) > 1e-15) {
          flag = 0;
          break;
          }
        else {
          continue;
          }
    }
    else{
        if (lambda == 0) {
            lambda = eigen_vec_entry/v[i];
            }
        else{
            if (fabs(lambda-eigen_vec_entry/v[i]) > 1e-13) {
                flag = 0;
                break;
                }
            else{
                continue;
                }
            }
        }  
  }
  free(v);
  
  if (flag == 1){
    printf("vec_%06d_%06d.in: Yes : %16.15e \n",*dim, *vec_num, lambda);
    fprintf(f_vec, "Eigenvalue %16.15e\n", lambda);
    }
  else{
    printf("vec_%06d_%06d.in: Not an eigenvector \n",*dim, *vec_num);
    }
  fclose(f_vec);
}

int main(){
  int dim;
  f_input(&dim);
  
  char mat_f_name[30];
  snprintf(mat_f_name,sizeof(mat_f_name),"mat_%06d.in",dim);
  FILE *f_mat  = fopen(mat_f_name, "r");
  printf("Opening mat_%06d.in\n",dim);
  
  double **A = (double**)malloc(dim * sizeof(double*));
  int i,j;
  for(i=0; i<dim; i++) {
    A[i] = (double*)malloc(dim * sizeof(double));
    for(j=0; j<dim; j++) {
      fscanf(f_mat, "%lf,", &A[i][j]);
      }
    }
  printf("Loaded in Memory. Closing mat_%06d.in \n\n",dim);
  fclose(f_mat);
  
  for (i=1; i<5; i++) {
    eigen_evaluate(A, &dim, &i);
    }
  
  for (i = 0; i < dim; i++) {
    free(A[i]);
    }
  free(A);
  
  return 0;
}