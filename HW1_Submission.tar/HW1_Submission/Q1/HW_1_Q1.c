#include<stdio.h>

void print_to_file(double** A, int mat_size, int format_flag) {
    
    FILE *fid;
    char f_name[30];
    
    if (format_flag == 0) { 
        snprintf(f_name,sizeof(f_name),"array_%06d_asc.out");
        fid = fopen(f_name, "w");
        }
    else{
        if (format_flag == 1) {
           snprintf(f_name,sizeof(f_name),"array_%06d_bin.out");
           fid = fopen(f_name, "wb");
           }
        else {
           printf("Invalid Format Flag");
           }
        }   
    
    int i,j;
    for (i = 0; i < mat_size; i++) {
        for (j = 0; j < mat_size; j++) {
            fprintf(fid, "%16.15e ", A[i][j]);
        }
        fprintf(fid, "\n");
    }
    
    printf("2D array written to file: %s\n", f_name);
    fclose(fid);
}

int main(){

FILE *fptr;
int mat_size;

fptr = fopen("input.in", "r");
if (fptr == NULL) { 
  printf("No such file\n");
  }
else {
  printf("Opening file\n");
  fscanf(fptr, "%d\n", &mat_size);
  printf("%d\n",mat_size);
  fclose(fptr);
  printf("Matrix size acquired. Closing file\n");
  }

double **A = (double**)malloc(mat_size * sizeof(double*));

int i,j;
for(i=0; i<mat_size; i++) {
  A[i] = (double*)malloc(mat_size*sizeof(double));
  for(j=0; j<mat_size; j++) {
     A[i][j]=i+j;
     }  
  }

print_to_file(A, mat_size, 1);

for (i = 0; i < mat_size; i++) {
  free(A[i]);
  }
free(A);

return 0;
}
